import speech_recognition as sr
import pyttsx3
import webbrowser
from googletrans import Translator

engine = pyttsx3.init()
engine.setProperty('rate', 150)

translator = Translator()

def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

def take_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        try:
            audio = r.listen(source)
            print("Recognizing...")
            query = r.recognize_google(audio, language='hi-IN')
            translated = translator.translate(query, dest='en')
            command = translated.text.lower()
            print("Tumne kaha:", command)
            return command
        except Exception as e:
            print("Error:", str(e))
            return ""

def run_assistant():
    speak("Namaste! Main sun raha hoon.")
    while True:
        query = take_command()

        if "youtube" in query:
            speak("Opening YouTube")
            webbrowser.open("https://www.youtube.com")
        elif "chrome" in query:
            speak("Opening Chrome")
            webbrowser.open("https://www.google.com")
        elif "band kar" in query or "exit" in query or "close" in query:
            speak("Assistant band ho raha hai.")
            break
        elif query.strip() == "":
            speak("Kuch samajh nahi aaya. Dobara boliye.")
        else:
            speak("Mujhe yeh command samajh nahi aayi.")

run_assistant()

